package arifeen.mahmud.webScrapingSelenium;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebScrapingSeleniumApplicationTests {

	@Test
	void contextLoads() {
	}

}
