package arifeen.mahmud.webScrapingSelenium.configuration;

import javax.annotation.PostConstruct;

import org.openqa.selenium.chrome.ChromeDriver;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SeleniumConfiguration {
	
	@PostConstruct
	void postConstruct() {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\arifeen.mahmud\\Documents\\workspace-spring-tool-suite-4-4.16.1.RELEASE\\webScrapingSelenium\\chromedriver.exe");
	}
	
	@Bean
	public ChromeDriver driver() {
		return new ChromeDriver();
		
	}

}
