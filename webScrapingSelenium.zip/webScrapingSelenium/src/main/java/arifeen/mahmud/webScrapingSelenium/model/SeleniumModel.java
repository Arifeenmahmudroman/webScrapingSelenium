package arifeen.mahmud.webScrapingSelenium.model;

import javax.persistence.*;

import lombok.Data;
import org.hibernate.annotations.GeneratorType;

@Data
@Entity
@Table(name = "ArifeenSeleniumData2")
public class SeleniumModel {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    private String relatadAlldata;


	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getRelatadAlldata() {
        return relatadAlldata;
    }


    public void setRelatadAlldata(String relatadAlldata) {
        this.relatadAlldata = relatadAlldata;
    }


    @Override
    public String toString() {
        return "SeleniumModel{" +
                "id=" + id +
                ", relatadAlldata='" + relatadAlldata + '\'' +
                '}';
    }

}
