package arifeen.mahmud.webScrapingSelenium.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import arifeen.mahmud.webScrapingSelenium.model.SeleniumModel;

public interface SeleniumRepo extends JpaRepository<SeleniumModel, Integer>{

}
