package arifeen.mahmud.webScrapingSelenium.service;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import arifeen.mahmud.webScrapingSelenium.model.SeleniumModel;
import arifeen.mahmud.webScrapingSelenium.repository.SeleniumRepo;
import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
public class ScraperService {
	
	

	@Autowired
	SeleniumRepo seleniumRepo;
	private static final String URL = "https://relatedwords.org/relatedto/";
	
	private ChromeDriver driver;
	
	@PostConstruct
	void postConstruct() {
		scrape("Hello");
	}
	List<SeleniumModel> listModel = new ArrayList<>();

	public void scrape(final String value) {
		
		driver.get(URL+value);
		
	    List<String> list = new ArrayList<>();		
		final WebElement wordElement = driver.findElement(By.className("words"));
		final List<WebElement> wordList = wordElement.findElements(By.tagName("a"));
		wordList.forEach(word-> list.add(word.getText()));
		
		
//Long i =1L;
		for(String str:list) {

//			System.out.println("===>"+str);
			SeleniumModel seleniumModel = new SeleniumModel();
//			seleniumModel.setId(i);
			seleniumModel.setRelatadAlldata(str);
//			seleniumRepo.save(seleniumModel);
			listModel.add(seleniumModel);
//			i++;
			
		}
		System.out.println(listModel);
		seleniumRepo.saveAll(listModel);
		
				
		
//		try {
//			PrintStream myconsolePrintStream = new PrintStream(new File("N://webdata.text"));
//			System.setOut(myconsolePrintStream);
//			myconsolePrintStream.print("Ratul");
//			
//		} catch (FileNotFoundException fx) {
//			System.out.println(fx);
//		}
//		
		
		driver.quit();
	}
}
